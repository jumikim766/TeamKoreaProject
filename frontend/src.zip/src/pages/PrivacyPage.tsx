import Header from "../components/Header";
import Navbar from "../components/Navbar";
import type { ViewMode } from "../App";
import privacyData from "../data/privacy.json";
import "../styles/Policy.css";
import { useEffect } from "react";

type ThemeMode = "light" | "dark";

type PrivacyPageProps = {
  theme: ThemeMode;
  isLoggedIn: boolean;
  userName?: string;
  onLogout: () => void;
  onNavigate: (view: ViewMode) => void;
  onToggleTheme: () => void;
  onGoHome: () => void;
  onGoLogin: () => void;
  onGoSignup: () => void;
  onGoMyPage: () => void;
};

type Chapter = {
  chapterId: string;
  chapterTitle: string;
  sections: Section[];
};

type Section = {
  sectionId: string;
  sectionTitle: string;
  sectionContent: string[];
};

const chapters: Chapter[] = privacyData as Chapter[];

function scrollToId(id: string) {
  const el = document.getElementById(id);
  if (!el) return;
  const offset = 140;
  const top = el.getBoundingClientRect().top + window.scrollY - offset;
  window.scrollTo({ top, behavior: "smooth" });
}

function PrivacyPage({
  theme,
  isLoggedIn,
  userName,
  onLogout,
  onNavigate,
  onToggleTheme,
  onGoHome,
  onGoLogin,
  onGoSignup,
  onGoMyPage,
}: PrivacyPageProps) {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className={`dashboard-shell ${theme}`}>
      <Header
        theme={theme}
        currentView="privacy"
        isLoggedIn={isLoggedIn}
        userName={userName}
        onLogout={onLogout}
        onToggleTheme={onToggleTheme}
        onGoHome={onGoHome}
        onGoLogin={onGoLogin}
        onGoSignup={onGoSignup}
        onGoMyPage={onGoMyPage}
      />

      <Navbar onNavigate={onNavigate} />

      <main className="policy-page">
        <div className="policy-heading">
          <button className="back-button" onClick={onGoHome} type="button">
            뒤로가기
          </button>
          <p className="policy-eyebrow">URL GUARD</p>
          <h1 className="policy-title">개인정보 처리방침</h1>
        </div>

        <div className="policy-toc-box">
          <div className="policy-toc-grid">
            {chapters.map((ch) => (
              <div key={ch.chapterId} className="policy-toc-col">
                <button
                  type="button"
                  className="policy-toc-chapter"
                  onClick={() => scrollToId(ch.chapterId)}
                >
                  {ch.chapterTitle}
                </button>

                {ch.sections.map((sec) => (
                  <button
                    key={sec.sectionId}
                    type="button"
                    className="policy-toc-section"
                    onClick={() => scrollToId(sec.sectionId)}
                  >
                    {sec.sectionTitle}
                  </button>
                ))}
              </div>
            ))}
          </div>
        </div>

        <div className="policy-body">
          {chapters.map((ch) => (
            <section
              key={ch.chapterId}
              id={ch.chapterId}
              className="policy-chapter"
            >
              <h2 className="policy-chapter-title">{ch.chapterTitle}</h2>

              {ch.sections.map((sec) => (
                <div
                  key={sec.sectionId}
                  id={sec.sectionId}
                  className="policy-section"
                >
                  <h3 className="policy-section-title">{sec.sectionTitle}</h3>

                  <div className="policy-section-body">
                    {sec.sectionContent.map((line, idx) => (
                      <p key={idx} className="policy-line">
                        {line}
                      </p>
                    ))}
                  </div>
                </div>
              ))}
            </section>
          ))}
        </div>
      </main>
      <button
        className="top-button"
        onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
      >
        ↑
      </button>
    </div>
  );
}

export default PrivacyPage;
